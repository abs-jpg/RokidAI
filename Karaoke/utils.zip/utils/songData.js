// 示例歌曲数据模块
// 注意：歌曲伴奏、歌词及标准音高数据为外部版权依赖，
// 此处使用预置示例数据（标注为示例），真实部署需接入受版权保护的数字曲库。

// 生成参考 MIDI 音高曲线：每秒一个采样点，值为 MIDI note number
// 这些是手工编写的示意性旋律轮廓，非真实歌曲的完整音高数据
function genRefNotes(notes) {
  // notes: [{ midi, start, dur }] start/dur 单位秒
  // 展开为每 0.1s 一个采样点的连续数组
  const result = [];
  const totalDuration = notes.reduce((max, n) => Math.max(max, n.start + n.dur), 0);
  const points = Math.ceil(totalDuration * 10); // 每0.1s一个点
  for (let i = 0; i < points; i++) {
    const t = i / 10;
    let found = false;
    for (const n of notes) {
      if (t >= n.start && t < n.start + n.dur) {
        result.push(n.midi);
        found = true;
        break;
      }
    }
    if (!found) {
      result.push(null); // 无参考音（间奏/休止）
    }
  }
  return result;
}

// MIDI note 参考：
// 60 = C4 (中央C), 62 = D4, 64 = E4, 65 = F4, 67 = G4, 69 = A4(440Hz), 71 = B4, 72 = C5
// 低八度: 48 = C3, 50 = D3, 52 = E3, 55 = G3
// 高八度: 72 = C5, 74 = D5, 76 = E5, 79 = G5

export const songs = [
  {
    id: 'yequ',
    name: '夜曲',
    artist: '周杰伦',
    difficulty: 3,
    duration: 30, // 示例截取30秒片段
    isDemo: true,
    accompaniment: '/assets/demo_accompaniment.ogg',
    lyrics: [
      { time: 0, text: '一群嗜血的蝙蝠 被你吸引' },
      { time: 4, text: '面无表情 孤独混在人群里' },
      { time: 8, text: '你虚度的光阴 被你重温' },
      { time: 12, text: '夜曲 倾泄而出' },
      { time: 16, text: '为你弹奏萧邦的夜曲' },
      { time: 20, text: '纪念我死去的爱情' },
      { time: 24, text: '跟夜风一样的声音' },
      { time: 28, text: '心碎得很好听' }
    ],
    // 示意性旋律轮廓（非真实音高数据）
    refNotes: genRefNotes([
      { midi: 60, start: 0, dur: 1 },
      { midi: 62, start: 1, dur: 0.5 },
      { midi: 64, start: 1.5, dur: 1 },
      { midi: 65, start: 2.5, dur: 0.5 },
      { midi: 64, start: 3, dur: 1 },
      { midi: 60, start: 4, dur: 1 },
      { midi: 62, start: 5, dur: 0.5 },
      { midi: 67, start: 5.5, dur: 1.5 },
      { midi: 65, start: 7, dur: 1 },
      { midi: 64, start: 8, dur: 1 },
      { midi: 60, start: 9, dur: 1 },
      { midi: 62, start: 10, dur: 1 },
      { midi: 64, start: 11, dur: 1 },
      { midi: 67, start: 12, dur: 2 },
      { midi: 65, start: 14, dur: 2 },
      { midi: 64, start: 16, dur: 1 },
      { midi: 65, start: 17, dur: 0.5 },
      { midi: 67, start: 17.5, dur: 1.5 },
      { midi: 69, start: 19, dur: 1 },
      { midi: 67, start: 20, dur: 1 },
      { midi: 65, start: 21, dur: 1 },
      { midi: 64, start: 22, dur: 1 },
      { midi: 60, start: 23, dur: 1 },
      { midi: 62, start: 24, dur: 1 },
      { midi: 64, start: 25, dur: 1 },
      { midi: 65, start: 26, dur: 1 },
      { midi: 67, start: 27, dur: 1 },
      { midi: 69, start: 28, dur: 2 }
    ])
  },
  {
    id: 'xiaoxingyun',
    name: '小幸运',
    artist: '田馥甄',
    difficulty: 2,
    duration: 30,
    isDemo: true,
    accompaniment: '/assets/demo_accompaniment.ogg',
    lyrics: [
      { time: 0, text: '我听见雨滴落在青青草地' },
      { time: 4, text: '我听见远方下课钟声响起' },
      { time: 8, text: '可是我没有听见你的声音' },
      { time: 12, text: '认真 呼唤 哪姓名' },
      { time: 16, text: '爱上你的时候还不懂感情' },
      { time: 20, text: '离别了才觉得刻骨 铭心' },
      { time: 24, text: '为什么没有发现遇见了你' },
      { time: 28, text: '是生命最好的事情' }
    ],
    refNotes: genRefNotes([
      { midi: 64, start: 0, dur: 1 },
      { midi: 65, start: 1, dur: 1 },
      { midi: 67, start: 2, dur: 1 },
      { midi: 69, start: 3, dur: 1 },
      { midi: 67, start: 4, dur: 1 },
      { midi: 65, start: 5, dur: 1 },
      { midi: 64, start: 6, dur: 1 },
      { midi: 60, start: 7, dur: 1 },
      { midi: 64, start: 8, dur: 1 },
      { midi: 65, start: 9, dur: 1 },
      { midi: 67, start: 10, dur: 1 },
      { midi: 69, start: 11, dur: 1 },
      { midi: 71, start: 12, dur: 2 },
      { midi: 69, start: 14, dur: 2 },
      { midi: 67, start: 16, dur: 1 },
      { midi: 65, start: 17, dur: 1 },
      { midi: 64, start: 18, dur: 1 },
      { midi: 65, start: 19, dur: 1 },
      { midi: 67, start: 20, dur: 1 },
      { midi: 69, start: 21, dur: 1 },
      { midi: 67, start: 22, dur: 1 },
      { midi: 65, start: 23, dur: 1 },
      { midi: 64, start: 24, dur: 1 },
      { midi: 65, start: 25, dur: 1 },
      { midi: 67, start: 26, dur: 1 },
      { midi: 69, start: 27, dur: 1 },
      { midi: 72, start: 28, dur: 2 }
    ])
  },
  {
    id: 'tonghua',
    name: '童话',
    artist: '光良',
    difficulty: 1,
    duration: 30,
    isDemo: true,
    accompaniment: '/assets/demo_accompaniment.ogg',
    lyrics: [
      { time: 0, text: '忘了有多久 再没听到你' },
      { time: 4, text: '对我说你 最爱的故事' },
      { time: 8, text: '我想了很久 我开始慌了' },
      { time: 12, text: '是不是我又 做错了什么' },
      { time: 16, text: '你哭着对我说 童话里都是骗人的' },
      { time: 20, text: '我不可能是你的王子' },
      { time: 24, text: '也许你不会懂' },
      { time: 28, text: '从你说爱我以后' }
    ],
    refNotes: genRefNotes([
      { midi: 60, start: 0, dur: 1 },
      { midi: 62, start: 1, dur: 1 },
      { midi: 64, start: 2, dur: 1 },
      { midi: 62, start: 3, dur: 1 },
      { midi: 60, start: 4, dur: 1 },
      { midi: 59, start: 5, dur: 1 },
      { midi: 57, start: 6, dur: 1 },
      { midi: 60, start: 7, dur: 1 },
      { midi: 62, start: 8, dur: 1 },
      { midi: 64, start: 9, dur: 1 },
      { midi: 65, start: 10, dur: 1 },
      { midi: 64, start: 11, dur: 1 },
      { midi: 62, start: 12, dur: 1 },
      { midi: 60, start: 13, dur: 1 },
      { midi: 59, start: 14, dur: 2 },
      { midi: 60, start: 16, dur: 0.5 },
      { midi: 62, start: 16.5, dur: 0.5 },
      { midi: 64, start: 17, dur: 0.5 },
      { midi: 65, start: 17.5, dur: 0.5 },
      { midi: 67, start: 18, dur: 1 },
      { midi: 65, start: 19, dur: 1 },
      { midi: 64, start: 20, dur: 1 },
      { midi: 62, start: 21, dur: 1 },
      { midi: 60, start: 22, dur: 1 },
      { midi: 62, start: 23, dur: 1 },
      { midi: 64, start: 24, dur: 1 },
      { midi: 65, start: 25, dur: 1 },
      { midi: 67, start: 26, dur: 1 },
      { midi: 69, start: 27, dur: 1 },
      { midi: 67, start: 28, dur: 2 }
    ])
  }
];

export function getSongById(id) {
  return songs.find(s => s.id === id) || null;
}

// 获取当前时间点的参考 MIDI 值
// refNotes 数组每 0.1s 一个采样点
export function getRefNoteAt(refNotes, timeSec) {
  const idx = Math.floor(timeSec * 10);
  if (idx < 0 || idx >= refNotes.length) return null;
  return refNotes[idx];
}

// 获取当前时间点的歌词行
export function getLyricAt(lyrics, timeSec) {
  let current = lyrics[0];
  for (const line of lyrics) {
    if (timeSec >= line.time) {
      current = line;
    } else {
      break;
    }
  }
  return current;
}
