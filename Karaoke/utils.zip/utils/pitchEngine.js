// 音准检测引擎
// 自相关法（autocorrelation）提取基频 F0，与参考 MIDI 音高曲线比对计算音准得分

/**
 * 从 AnalyserNode 提取基频 F0（Hz）
 * 使用自相关法：对时域信号做自相关，找到第一个显著峰值对应的周期，F0 = sampleRate / period
 * @param {AnalyserNode} analyser - 已连接到麦克风流源的 AnalyserNode
 * @returns {number|null} F0 频率（Hz），无法检测时返回 null
 */
export function extractF0(analyser) {
  if (!analyser) return null;

  const buffer = new Float32Array(analyser.fftSize);
  analyser.getFloatTimeDomainData(buffer);

  const size = buffer.length;

  // 计算 RMS，过滤静音段
  let rms = 0;
  for (let i = 0; i < size; i++) {
    rms += buffer[i] * buffer[i];
  }
  rms = Math.sqrt(rms / size);
  if (rms < 0.01) return null; // 静音阈值

  // 人声基频范围：80Hz ~ 1000Hz
  // 自相关搜索范围：lag 从 sampleRate/1000 到 sampleRate/80
  const sampleRate = analyser.context.sampleRate;
  const minLag = Math.floor(sampleRate / 1000); // 最高 1000Hz
  const maxLag = Math.floor(sampleRate / 80);   // 最低 80Hz

  // 计算自相关
  let bestLag = 0;
  let bestCorr = 0;

  for (let lag = minLag; lag <= maxLag; lag++) {
    let corr = 0;
    for (let i = 0; i < size - lag; i++) {
      corr += buffer[i] * buffer[i + lag];
    }
    // 归一化
    corr = corr / (size - lag);

    if (corr > bestCorr) {
      bestCorr = corr;
      bestLag = lag;
    }
  }

  if (bestLag === 0 || bestCorr < 0.1) return null; // 相关性太低

  // 抛物线插值提高精度
  const f0 = sampleRate / bestLag;

  // 验证在合理范围内
  if (f0 < 70 || f0 > 1100) return null;

  return f0;
}

/**
 * 频率（Hz）转 MIDI note number
 * MIDI 69 = A4 = 440Hz
 * @param {number} hz - 频率
 * @returns {number} MIDI note number（可带小数）
 */
export function hzToMidi(hz) {
  if (!hz || hz <= 0) return null;
  return 69 + 12 * Math.log2(hz / 440);
}

/**
 * 计算两个 MIDI 值之间的半音差（绝对值）
 * @param {number} midi1
 * @param {number} midi2
 * @returns {number} 半音差（绝对值）
 */
export function semitoneDiff(midi1, midi2) {
  if (midi1 == null || midi2 == null) return null;
  return Math.abs(midi1 - midi2);
}

/**
 * 计算音准得分
 * 对比用户 MIDI 轨迹与参考 MIDI 轨迹，统计平均半音偏差
 * 偏差 0 半音 = 100 分，±2 半音 ≈ 60 分，±5 半音 ≈ 20 分
 * @param {Array<number|null>} userMidiTrack - 用户逐帧 MIDI 值数组（每 0.1s 一个点）
 * @param {Array<number|null>} refMidiTrack - 参考 MIDI 值数组（每 0.1s 一个点）
 * @returns {{ score: number, avgOffset: number, matchedFrames: number, totalFrames: number }}
 */
export function calcAccuracyScore(userMidiTrack, refMidiTrack) {
  if (!userMidiTrack || !refMidiTrack || userMidiTrack.length === 0) {
    return { score: 0, avgOffset: 0, matchedFrames: 0, totalFrames: 0 };
  }

  let totalOffset = 0;
  let matchedFrames = 0;
  const totalFrames = Math.min(userMidiTrack.length, refMidiTrack.length);

  for (let i = 0; i < totalFrames; i++) {
    const userMidi = userMidiTrack[i];
    const refMidi = refMidiTrack[i];

    // 跳过任一方为 null 的帧（无用户音或无参考音）
    if (userMidi == null || refMidi == null) continue;

    const offset = Math.abs(userMidi - refMidi);
    totalOffset += offset;
    matchedFrames++;
  }

  if (matchedFrames === 0) {
    return { score: 0, avgOffset: 0, matchedFrames: 0, totalFrames };
  }

  const avgOffset = totalOffset / matchedFrames;

  // 评分映射：avgOffset 0 → 100, 2 → 60, 5 → 20
  // score = max(0, 100 - avgOffset * 20)
  // 0 半音: 100, 1: 80, 2: 60, 3: 40, 5: 0
  const score = Math.max(0, Math.min(100, Math.round(100 - avgOffset * 20)));

  return { score, avgOffset: Math.round(avgOffset * 10) / 10, matchedFrames, totalFrames };
}

/**
 * 逐帧记录用户 MIDI 值
 * 在录制过程中每 0.1s 调用一次，将当前 F0 转为 MIDI 并存入轨迹
 * @param {number|null} f0 - 当前帧 F0（Hz），无音时传 null
 * @returns {number|null} MIDI 值
 */
export function f0ToMidiTrackEntry(f0) {
  if (f0 == null) return null;
  return hzToMidi(f0);
}
