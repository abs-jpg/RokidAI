// 排行榜数据模块
// 开发阶段：wx.setStorageSync / wx.getStorageSync 本地存储降级，界面标注"未连接服务器"
// 真实路径：fetch POST/GET 自建服务器 API

import wx from 'wx';

const STORAGE_KEY = 'karaoke_leaderboard';
const SERVER_URL = ''; // 自建服务器 API 地址，部署后填写
const CONNECTED = false; // 服务器未部署，使用本地缓存

/**
 * 从本地存储读取排行榜数据
 * @returns {Array<{userId, songId, songName, score, accuracy, clarity, date}>}
 */
function readLocal() {
  try {
    const data = wx.getStorageSync(STORAGE_KEY);
    if (data && Array.isArray(data)) return data;
  } catch (e) {
    console.error('leaderboard readLocal error', e);
  }
  return [];
}

/**
 * 写入本地存储
 * @param {Array} list
 */
function writeLocal(list) {
  try {
    wx.setStorageSync(STORAGE_KEY, list);
  } catch (e) {
    console.error('leaderboard writeLocal error', e);
  }
}

/**
 * 生成简易用户 ID（首次使用时存入本地）
 * @returns {string}
 */
function getUserId() {
  try {
    let uid = wx.getStorageSync('karaoke_uid');
    if (!uid) {
      uid = 'user_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      wx.setStorageSync('karaoke_uid', uid);
    }
    return uid;
  } catch (e) {
    return 'user_guest';
  }
}

/**
 * 提交成绩到排行榜
 * 真实路径：fetch POST 到自建服务器
 * 开发阶段降级：存入本地 wx.setStorageSync
 * @param {{ songId: string, songName: string, score: number, accuracy: number, clarity: number }} entry
 * @returns {Promise<{ success: boolean, source: string, message?: string }>}
 */
export async function submitScore(entry) {
  const record = {
    userId: getUserId(),
    songId: entry.songId,
    songName: entry.songName,
    score: entry.score,
    accuracy: entry.accuracy,
    clarity: entry.clarity,
    date: new Date().toLocaleDateString('zh-CN')
  };

  if (CONNECTED && SERVER_URL) {
    try {
      const resp = await fetch(SERVER_URL + '/api/scores', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(record)
      });
      if (resp.ok) {
        return { success: true, source: 'server' };
      }
      return { success: false, source: 'server', message: '服务器返回错误' };
    } catch (e) {
      console.error('submitScore fetch error', e);
      // 网络失败时降级到本地
      saveScoreLocal(record);
      return { success: true, source: 'local-fallback', message: '服务器不可达，已存入本地' };
    }
  }

  // 本地降级
  saveScoreLocal(record);
  return { success: true, source: 'local', message: '未连接服务器，成绩已存入本地' };
}

/**
 * 将成绩存入本地存储（内部方法）
 * @param {Object} record
 */
function saveScoreLocal(record) {
  const list = readLocal();
  list.push(record);
  // 按分数降序排列
  list.sort((a, b) => b.score - a.score);
  // 保留前 50 条
  if (list.length > 50) list.length = 50;
  writeLocal(list);
}

/**
 * 保存成绩（同步接口，供不使用 Promise 的调用方使用）
 * @param {Object} record - 成绩记录
 */
export function saveScore(record) {
  saveScoreLocal({
    ...record,
    userId: getUserId(),
    date: record.date || new Date().toLocaleDateString('zh-CN')
  });
}

/**
 * 获取排行榜
 * 真实路径：fetch GET 从自建服务器
 * 开发阶段降级：从本地存储读取
 * @param {string} [songId] - 可选，按歌曲筛选
 * @returns {Promise<{ list: Array, source: string, connected: boolean }>}
 */
export async function getLeaderboard(songId) {
  if (CONNECTED && SERVER_URL) {
    try {
      const url = SERVER_URL + '/api/leaderboard' + (songId ? '?songId=' + songId : '');
      const resp = await fetch(url);
      if (resp.ok) {
        const list = await resp.json();
        return { list, source: 'server', connected: true };
      }
      return { list: readLocal(), source: 'local', connected: false };
    } catch (e) {
      console.error('getLeaderboard fetch error', e);
      return { list: readLocal(), source: 'local', connected: false };
    }
  }

  // 本地降级
  let list = readLocal();
  if (songId) {
    list = list.filter(item => item.songId === songId);
  }
  // 按分数降序
  list.sort((a, b) => b.score - a.score);
  return { list, source: 'local', connected: false };
}

/**
 * 检查是否已连接服务器
 * @returns {boolean}
 */
export function isServerConnected() {
  return CONNECTED;
}
