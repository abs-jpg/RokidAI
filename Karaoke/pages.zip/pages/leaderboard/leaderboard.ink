<script def>
{
  "usingComponents": {}
}
</script>

<script setup>
import wx from 'wx'
import { getLeaderboard } from '../../utils/leaderboard.js'

export default {
  data: {
    phase: 'loading',
    entries: [],
    selectedIdx: 0,
    sourceLabel: '',
    errorMsg: '',
    hintText: '上下浏览'
  },

  onLoad() {
    this.loadLeaderboard()
  },

  onShow() {
    // 每次回到页面刷新数据
    if (this.data.phase === 'display' || this.data.phase === 'empty') {
      this.loadLeaderboard()
    }
  },

  onKeyDown(event) {
    const code = event.code
    const phase = this.data.phase

    if (phase === 'loading') return

    if (phase === 'error') {
      if (code === 'Enter') this.loadLeaderboard()
      return
    }

    if (code === 'ArrowUp') {
      if (this.data.selectedIdx > 0) {
        this.setData({ selectedIdx: this.data.selectedIdx - 1 })
      }
    } else if (code === 'ArrowDown') {
      if (this.data.selectedIdx < this.data.entries.length - 1) {
        this.setData({ selectedIdx: this.data.selectedIdx + 1 })
      }
    }
  },

  onTapRetry() {
    this.loadLeaderboard()
  },

  async loadLeaderboard() {
    this.setData({ phase: 'loading', errorMsg: '' })

    this.loadDeadline = setTimeout(() => {
      if (this.data.phase === 'loading') {
        this.setData({ phase: 'error', errorMsg: '加载超时', hintText: '确认重试' })
      }
    }, 3000)

    try {
      const result = await getLeaderboard()
      if (this.loadDeadline) { clearTimeout(this.loadDeadline); this.loadDeadline = null }

      if (result.success && result.data && result.data.length > 0) {
        this.setData({
          phase: 'display',
          entries: result.data,
          selectedIdx: 0,
          sourceLabel: result.source || '',
          hintText: '上下浏览'
        })
      } else if (result.success && (!result.data || result.data.length === 0)) {
        this.setData({
          phase: 'empty',
          sourceLabel: result.source || '',
          hintText: '返回首页'
        })
      } else {
        this.setData({
          phase: 'error',
          errorMsg: result.message || '加载失败',
          hintText: '确认重试'
        })
      }
    } catch (e) {
      console.error('leaderboard load error', e, e && e.message)
      if (this.loadDeadline) { clearTimeout(this.loadDeadline); this.loadDeadline = null }
      this.setData({ phase: 'error', errorMsg: '加载失败', hintText: '确认重试' })
    }
  },

  onUnload() {
    if (this.loadDeadline) { clearTimeout(this.loadDeadline); this.loadDeadline = null }
  }
}
</script>

<page>
  <view class="page-root">
    <view class="topbar">
      <text class="title">排行榜</text>
    </view>

    <view class="source-bar" ink:if="{{sourceLabel}}">
      <text class="source-text">{{sourceLabel}}</text>
    </view>

    <view class="body-area" ink:if="{{phase === 'loading'}}">
      <text class="loading-text">加载中</text>
    </view>

    <view class="body-area" ink:if="{{phase === 'error'}}">
      <text class="error-text">{{errorMsg}}</text>
      <text class="error-sub">确认重试</text>
    </view>

    <view class="body-area" ink:if="{{phase === 'empty'}}">
      <text class="empty-text">暂无成绩</text>
      <text class="empty-sub">去唱一首吧</text>
    </view>

    <scroll-view class="body-scroll" ink:if="{{phase === 'display'}}" scroll-y="{{true}}">
      <view class="list">
        <view class="row" ink:for="{{entries}}" ink:key="rank">
          <text class="rank">{{item.rank}}</text>
          <text class="user-name">{{item.userName}}</text>
          <text class="song-name">{{item.songName}}</text>
          <text class="score">{{item.score}}</text>
          <view class="marker">
            <view class="dot" ink:if="{{selectedIdx === index}}"></view>
          </view>
        </view>
      </view>
    </scroll-view>

    <view class="hintbar">
      <text class="hint-text">{{hintText}}</text>
    </view>
  </view>
</page>

<style>
:root {
  --green-100: #40ff5e;
  --green-72: rgba(64,255,94,0.72);
  --green-48: rgba(64,255,94,0.48);
  --green-24: rgba(64,255,94,0.24);
  --green-12: rgba(64,255,94,0.12);
}

.page-root {
  display: flex;
  flex-direction: column;
  width: 448px;
  height: 328px;
}

.topbar {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  height: 28px;
  flex-shrink: 0;
}

.title {
  font-size: 16px;
  font-weight: bold;
  color: var(--green-100);
}

.source-bar {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  height: 16px;
  flex-shrink: 0;
}

.source-text {
  font-size: 9px;
  color: var(--green-24);
}

.body-area {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex: 1 1 auto;
  min-height: 0;
}

.loading-text {
  font-size: 14px;
  color: var(--green-48);
}

.error-text {
  font-size: 14px;
  color: var(--green-72);
}

.error-sub {
  font-size: 12px;
  color: var(--green-48);
  margin-top: 8px;
}

.empty-text {
  font-size: 16px;
  font-weight: bold;
  color: var(--green-48);
}

.empty-sub {
  font-size: 12px;
  color: var(--green-24);
  margin-top: 8px;
}

.body-scroll {
  flex: 1 1 auto;
  min-height: 0;
}

.list {
  display: flex;
  flex-direction: column;
}

.row {
  display: flex;
  flex-direction: row;
  align-items: center;
  height: 36px;
  flex-shrink: 0;
  padding: 0 8px;
}

.rank {
  font-size: 14px;
  font-weight: bold;
  color: var(--green-100);
  width: 28px;
  flex-shrink: 0;
}

.user-name {
  font-size: 12px;
  color: var(--green-72);
  width: 72px;
  flex-shrink: 0;
}

.song-name {
  font-size: 11px;
  color: var(--green-48);
  flex: 1 1 auto;
}

.score {
  font-size: 14px;
  font-weight: bold;
  color: var(--green-100);
  width: 36px;
  text-align: right;
  flex-shrink: 0;
}

.marker {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 10px;
  flex-shrink: 0;
}

.dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background-color: var(--green-100);
}

.hintbar {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  height: 18px;
  flex-shrink: 0;
}

.hint-text {
  font-size: 10px;
  color: var(--green-24);
}
</style>