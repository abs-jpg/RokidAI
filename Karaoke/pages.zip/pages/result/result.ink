<script def>
{
  "usingComponents": {}
}
</script>

<script setup>
import wx from 'wx'
import { getSongById } from '../../utils/songData.js'
import { calcAccuracyScore } from '../../utils/pitchEngine.js'
import { calcClarityScore, calcTotalScore, getGrade } from '../../utils/scoreEngine.js'
import { submitScore } from '../../utils/leaderboard.js'

export default {
  data: {
    phase: 'calculating',
    songId: '',
    songName: '',
    accuracyScore: 0,
    clarityScore: 0,
    totalScore: 0,
    grade: '',
    gradeLabel: '',
    clarityEstimated: true,
    displayScore: 0,
    displayAccuracy: 0,
    displayClarity: 0,
    submitStatus: 'idle',
    submitMsg: '',
    errorMsg: '',
    selectedIdx: 0,
    actionLabels: ['提交成绩', '重唱', '返回首页'],
    hintText: '评分计算中'
  },

  onLoad(query) {
    const songId = query && query.songId ? query.songId : 'yequ'
    const song = getSongById(songId)
    this.setData({
      songId: songId,
      songName: song ? song.name : '未知歌曲'
    })
    this.calculateScore(songId, song)
  },

  onUnload() {
    if (this.animTimer) { clearInterval(this.animTimer); this.animTimer = null }
    if (this.calcDeadline) { clearTimeout(this.calcDeadline); this.calcDeadline = null }
  },

  onKeyDown(event) {
    const code = event.code
    const phase = this.data.phase

    if (phase === 'calculating') return

    if (phase === 'error') {
      if (code === 'Enter') this.recalculate()
      return
    }

    if (code === 'ArrowUp') {
      const idx = (this.data.selectedIdx - 1 + 3) % 3
      this.setData({ selectedIdx: idx })
    } else if (code === 'ArrowDown') {
      const idx = (this.data.selectedIdx + 1) % 3
      this.setData({ selectedIdx: idx })
    } else if (code === 'Enter') {
      this.activateAction(this.data.selectedIdx)
    }
  },

  onTapAction(e) {
    const idx = e && e.currentTarget && e.currentTarget.dataset ? Number(e.currentTarget.dataset.idx) : 0
    this.activateAction(idx)
  },

  activateAction(idx) {
    if (idx === 0) {
      this.doSubmit()
    } else if (idx === 1) {
      wx.navigateBack()
    } else if (idx === 2) {
      wx.navigateBack({ delta: 2 })
    }
  },

  calculateScore(songId, song) {
    let recording = null
    try {
      recording = wx.getStorageSync('karaoke_last_recording')
    } catch (e) {
      console.error('read recording error', e)
    }

    this.calcDeadline = setTimeout(() => {
      if (this.data.phase === 'calculating') {
        this.setData({ phase: 'error', errorMsg: '评分计算超时', hintText: '确认重试' })
      }
    }, 5000)

    setTimeout(() => {
      if (this.data.phase !== 'calculating') return

      if (!recording || !recording.userMidiTrack) {
        if (this.calcDeadline) { clearTimeout(this.calcDeadline); this.calcDeadline = null }
        this.setData({ phase: 'error', errorMsg: '录音数据缺失', hintText: '确认重试' })
        return
      }

      const userTrack = recording.userMidiTrack
      const refTrack = song ? song.refNotes : recording.refNotes

      const accResult = calcAccuracyScore(userTrack, refTrack)
      const claResult = calcClarityScore({
        validFrames: recording.validFrames || 0,
        totalFrames: recording.totalFrames || userTrack.length
      })
      const total = calcTotalScore(accResult.score, claResult.score)
      const gradeInfo = getGrade(total)

      if (this.calcDeadline) { clearTimeout(this.calcDeadline); this.calcDeadline = null }

      this.setData({
        phase: 'display',
        accuracyScore: accResult.score,
        clarityScore: claResult.score,
        totalScore: total,
        grade: gradeInfo.grade,
        gradeLabel: gradeInfo.label,
        clarityEstimated: claResult.isEstimated,
        hintText: '上下选择 确认执行'
      })

      this.startScoreAnimation(total, accResult.score, claResult.score)
    }, 1200)
  },

  recalculate() {
    if (this.animTimer) { clearInterval(this.animTimer); this.animTimer = null }
    this.setData({
      phase: 'calculating',
      displayScore: 0,
      displayAccuracy: 0,
      displayClarity: 0,
      selectedIdx: 0,
      submitStatus: 'idle',
      submitMsg: '',
      errorMsg: '',
      hintText: '评分计算中'
    })
    const song = getSongById(this.data.songId)
    this.calculateScore(this.data.songId, song)
  },

  startScoreAnimation(targetTotal, targetAcc, targetCla) {
    const duration = 800
    const startTime = performance.now()

    this.animTimer = setInterval(() => {
      const elapsed = performance.now() - startTime
      const progress = Math.min(1, elapsed / duration)
      const eased = 1 - Math.pow(1 - progress, 3)

      this.setData({
        displayScore: Math.round(targetTotal * eased),
        displayAccuracy: Math.round(targetAcc * eased),
        displayClarity: Math.round(targetCla * eased)
      })

      if (progress >= 1) {
        clearInterval(this.animTimer)
        this.animTimer = null
      }
    }, 33)
  },

  async doSubmit() {
    if (this.data.submitStatus === 'submitting') return
    this.setData({ submitStatus: 'submitting', submitMsg: '提交中' })

    try {
      const result = await submitScore({
        songId: this.data.songId,
        songName: this.data.songName,
        score: this.data.totalScore,
        accuracy: this.data.accuracyScore,
        clarity: this.data.clarityScore
      })
      if (result.success) {
        this.setData({ submitStatus: 'done', submitMsg: result.message || '已提交' })
      } else {
        this.setData({ submitStatus: 'error', submitMsg: result.message || '提交失败' })
      }
    } catch (e) {
      console.error('submit error', e)
      this.setData({ submitStatus: 'error', submitMsg: '提交失败' })
    }
  }
}
</script>

<page>
  <view class="page-root">
    <view class="topbar">
      <text class="song-name">{{songName}}</text>
    </view>

    <view class="body-area" ink:if="{{phase === 'calculating'}}">
      <text class="calc-text">评分计算中</text>
      <view class="calc-dots">
        <view class="dot dot1"></view>
        <view class="dot dot2"></view>
        <view class="dot dot3"></view>
      </view>
    </view>

    <view class="body-area" ink:if="{{phase === 'error'}}">
      <text class="error-text">{{errorMsg}}</text>
      <text class="error-sub">确认重试</text>
    </view>

    <view class="body-area" ink:if="{{phase === 'display'}}">
      <view class="score-hero">
        <view class="grade-row">
          <text class="grade-letter">{{grade}}</text>
          <text class="grade-label">{{gradeLabel}}</text>
        </view>
        <text class="score-num">{{displayScore}}</text>
        <text class="score-unit">综合评分</text>
      </view>

      <view class="sub-scores">
        <view class="sub-row">
          <text class="sub-name">音准</text>
          <view class="bar-track">
            <view class="bar-fill" style="width: {{displayAccuracy}}%;"></view>
          </view>
          <text class="sub-num">{{accuracyScore}}</text>
        </view>
        <view class="sub-row">
          <view class="sub-name-row">
            <text class="sub-name">清晰度</text>
            <text class="est-tag" ink:if="{{clarityEstimated}}">待接入</text>
          </view>
          <view class="bar-track">
            <view class="bar-fill" style="width: {{displayClarity}}%;"></view>
          </view>
          <text class="sub-num">{{clarityScore}}</text>
        </view>
      </view>

      <view class="submit-line" ink:if="{{submitStatus !== 'idle'}}">
        <text class="submit-msg">{{submitMsg}}</text>
      </view>

      <view class="action-row">
        <view class="action-btn" ink:for="{{actionLabels}}" ink:key="*this" bindtap="onTapAction" data-idx="{{index}}">
          <text class="action-label">{{item}}</text>
          <view class="action-marker">
            <view class="action-dot" ink:if="{{selectedIdx === index}}"></view>
          </view>
        </view>
      </view>
    </view>

    <view class="hintbar">
      <text class="hint-text">{{hintText}}</text>
    </view>
  </view>
</page>

<style>
:root {
  --green-100: #40ff5e;
  --green-72: rgba(64,255,94,0.72);
  --green-48: rgba(64,255,94,0.48);
  --green-24: rgba(64,255,94,0.24);
  --green-12: rgba(64,255,94,0.12);
}

.page-root {
  display: flex;
  flex-direction: column;
  width: 448px;
  height: 328px;
}

.topbar {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  height: 28px;
  flex-shrink: 0;
}

.song-name {
  font-size: 14px;
  font-weight: bold;
  color: var(--green-100);
}

.body-area {
  display: flex;
  flex-direction: column;
  align-items: center;
  flex: 1 1 auto;
  min-height: 0;
  padding: 0 16px;
}

.calc-text {
  font-size: 16px;
  color: var(--green-72);
}

.calc-dots {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  margin-top: 12px;
}

.dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background-color: var(--green-48);
  margin: 0 4px;
}

.error-text {
  font-size: 16px;
  color: var(--green-72);
}

.error-sub {
  font-size: 12px;
  color: var(--green-48);
  margin-top: 8px;
}

.score-hero {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 110px;
  flex-shrink: 0;
}

.grade-row {
  display: flex;
  flex-direction: row;
  align-items: center;
}

.grade-letter {
  font-size: 28px;
  font-weight: bold;
  color: var(--green-100);
}

.grade-label {
  font-size: 12px;
  color: var(--green-48);
  margin-left: 6px;
}

.score-num {
  font-size: 48px;
  font-weight: bold;
  color: var(--green-100);
  margin-top: 2px;
}

.score-unit {
  font-size: 11px;
  color: var(--green-24);
}

.sub-scores {
  display: flex;
  flex-direction: column;
  width: 100%;
  flex-shrink: 0;
  margin-top: 6px;
}

.sub-row {
  display: flex;
  flex-direction: row;
  align-items: center;
  height: 28px;
}

.sub-name {
  font-size: 11px;
  color: var(--green-48);
  width: 56px;
  flex-shrink: 0;
}

.sub-name-row {
  display: flex;
  flex-direction: row;
  align-items: center;
  width: 56px;
  flex-shrink: 0;
}

.est-tag {
  font-size: 9px;
  color: var(--green-48);
  border: 1px dashed var(--green-48);
  padding: 0 2px;
  margin-left: 4px;
}

.bar-track {
  position: relative;
  flex: 1 1 auto;
  height: 10px;
  background-color: var(--green-12);
  border: 1px solid var(--green-24);
}

.bar-fill {
  height: 100%;
  background-color: var(--green-72);
}

.sub-num {
  font-size: 14px;
  font-weight: bold;
  color: var(--green-100);
  width: 32px;
  text-align: right;
  flex-shrink: 0;
}

.submit-line {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  height: 16px;
}

.submit-msg {
  font-size: 10px;
  color: var(--green-48);
}

.action-row {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-around;
  height: 40px;
  flex-shrink: 0;
  margin-top: 6px;
}

.action-btn {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  flex: 1 1 auto;
  height: 100%;
  margin: 0 4px;
}

.action-label {
  font-size: 13px;
  color: var(--green-72);
}

.action-marker {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 8px;
  margin-left: 4px;
}

.action-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background-color: var(--green-100);
}

.hintbar {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  height: 18px;
  flex-shrink: 0;
}

.hint-text {
  font-size: 10px;
  color: var(--green-24);
}
</style>