<script def>
{
  "usingComponents": {}
}
</script>

<script setup>
import wx from 'wx'
import { getSongById } from '../../utils/songData.js'
import { extractF0, hzToMidi } from '../../utils/pitchEngine.js'

export default {
  data: {
    phase: 'loading',
    songId: '',
    songName: '',
    artist: '',
    currentLyric: '',
    nextLyric: '',
    elapsedSec: 0,
    totalSec: 180,
    countdownNum: 3,
    errorMsg: '',
    hintText: '确认开始'
  },

  onLoad(query) {
    const songId = query && query.songId ? query.songId : 'yequ'
    const song = getSongById(songId)
    if (!song) {
      this.setData({ phase: 'error', errorMsg: '歌曲数据缺失', hintText: '返回重选' })
      return
    }
    this.songData = song
    this.setData({
      songId: songId,
      songName: song.name,
      artist: song.artist,
      totalSec: Math.round((song.duration || 180000) / 1000),
      currentLyric: song.lyrics && song.lyrics.length > 0 ? song.lyrics[0].text : '',
      nextLyric: song.lyrics && song.lyrics.length > 1 ? song.lyrics[1].text : ''
    })
    this.prepareAudio()
  },

  onHide() { this.cleanup() },
  onUnload() { this.cleanup() },

  onKeyDown(event) {
    const code = event.code
    const phase = this.data.phase

    if (phase === 'loading') {
      if (code === 'Enter') this.startCountdown()
    } else if (phase === 'error') {
      if (code === 'Enter') this.prepareAudio()
    } else if (phase === 'recording') {
      if (code === 'Enter') this.stopRecording()
    } else if (phase === 'settling') {
      if (code === 'Enter') this.goToResult()
    }
  },

  onTapMain() {
    const phase = this.data.phase
    if (phase === 'loading' || phase === 'error') {
      this.prepareAudio()
    } else if (phase === 'recording') {
      this.stopRecording()
    } else if (phase === 'settling') {
      this.goToResult()
    }
  },

  async prepareAudio() {
    this.setData({ phase: 'loading', errorMsg: '', hintText: '确认开始' })
    try {
      const song = this.songData
      if (!song || !song.audioSrc) {
        this.setData({ phase: 'loading', hintText: '确认开始（示例伴奏）' })
        return
      }
      const { AudioPlayer, Sound } = await import('audio')
      this.audioPlayer = new AudioPlayer()
      this.sound = new Sound(song.audioSrc)
      this.setData({ phase: 'loading', hintText: '确认开始' })
    } catch (e) {
      console.error('audio prepare error', e, e && e.message)
      this.setData({ phase: 'loading', hintText: '确认开始（示例伴奏）' })
    }
  },

  startCountdown() {
    this.setData({ phase: 'countdown', countdownNum: 3, hintText: '准备…' })
    let count = 3
    this.countdownTimer = setInterval(() => {
      count--
      if (count <= 0) {
        clearInterval(this.countdownTimer)
        this.countdownTimer = null
        this.startRecording()
      } else {
        this.setData({ countdownNum: count })
      }
    }, 1000)
  },

  async startRecording() {
    this.setData({ phase: 'recording', elapsedSec: 0, hintText: '确认停止' })
    this.userMidiTrack = []
    this.validFrames = 0
    this.totalFrames = 0
    this.recordStartTime = performance.now()

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      this.mediaStream = stream
      const AudioContextClass = window.AudioContext || window.webkitAudioContext
      if (!AudioContextClass) {
        this.setData({ phase: 'error', errorMsg: '音频上下文不可用', hintText: '确认重试' })
        return
      }
      this.audioContext = new AudioContextClass()
      if (this.audioContext.state === 'suspended') await this.audioContext.resume()
      this.sourceNode = this.audioContext.createMediaStreamSource(stream)
      this.analyser = this.audioContext.createAnalyser()
      this.analyser.fftSize = 2048
      this.sourceNode.connect(this.analyser)
      // AnalyserNode 不连接 destination，防反馈
    } catch (micErr) {
      console.error('mic error', micErr, micErr && micErr.message)
      this.setData({ phase: 'error', errorMsg: '麦克风不可用，请在系统设置中开启', hintText: '确认重试' })
      return
    }

    // 播放伴奏
    if (this.audioPlayer && this.sound) {
      try { this.audioPlayer.play(this.sound) } catch (e) { console.error('audio play err', e) }
    }

    this.startDrawLoop()
  },

  startDrawLoop() {
    if (this.drawTimer) clearInterval(this.drawTimer)
    this.drawTimer = setInterval(() => { this.drawFrame() }, 40)
  },

  drawFrame() {
    const ctx = wx.createCanvasContext('pitchCanvas')
    if (!ctx) return

    const W = 448
    const H = 180
    const elapsed = performance.now() - this.recordStartTime
    this.setData({ elapsedSec: Math.round(elapsed / 1000) })

    ctx.clearRect(0, 0, W, H)

    const song = this.songData
    const refNotes = song ? song.refNotes : null
    const minMidi = 48
    const maxMidi = 72
    const midiRange = maxMidi - minMidi
    const visibleMs = 30000
    const startMs = Math.max(0, elapsed - visibleMs)
    const endMs = elapsed

    // 参考曲线 48% 亮度
    if (refNotes && refNotes.length > 0) {
      ctx.strokeStyle = 'rgba(64,255,94,0.48)'
      ctx.lineWidth = 2
      ctx.beginPath()
      let started = false
      for (let i = 0; i < refNotes.length; i++) {
        const note = refNotes[i]
        if (note.timeMs > endMs) break
        if (note.timeMs + (note.durMs || 500) < startMs) continue
        const x = ((note.timeMs - startMs) / visibleMs) * W
        const y = H - ((note.midi - minMidi) / midiRange) * H
        if (!started) { ctx.moveTo(x, y); started = true }
        else { ctx.lineTo(x, y) }
      }
      ctx.stroke()
    }

    // 用户 F0 线 100% 亮度
    if (this.analyser) {
      const f0 = extractF0(this.analyser)
      this.totalFrames++
      if (f0 > 0) {
        this.validFrames++
        const midi = hzToMidi(f0)
        this.userMidiTrack.push({ timeMs: elapsed, midi: midi })
        const clampedMidi = Math.max(minMidi, Math.min(maxMidi, midi))
        const x = W - 4
        const y = H - ((clampedMidi - minMidi) / midiRange) * H
        const refMidi = this.getRefMidiAt(elapsed)
        const deviation = refMidi > 0 ? Math.abs(midi - refMidi) : 0
        const isOff = deviation > 2

        // 偏离时变粗
        ctx.strokeStyle = isOff ? 'rgba(64,255,94,0.48)' : '#40ff5e'
        ctx.lineWidth = isOff ? 4 : 2
        ctx.beginPath()
        ctx.arc(x, y, 3, 0, 2 * Math.PI)
        ctx.stroke()
        ctx.fillStyle = '#40ff5e'
        ctx.fill()

        // 用户轨迹线段
        if (this.userMidiTrack.length > 1) {
          ctx.strokeStyle = '#40ff5e'
          ctx.lineWidth = 2
          ctx.beginPath()
          const trackStart = Math.max(0, this.userMidiTrack.length - 100)
          for (let i = trackStart; i < this.userMidiTrack.length; i++) {
            const pt = this.userMidiTrack[i]
            const px = ((pt.timeMs - startMs) / visibleMs) * W
            const cMidi = Math.max(minMidi, Math.min(maxMidi, pt.midi))
            const py = H - ((cMidi - minMidi) / midiRange) * H
            if (i === trackStart) ctx.moveTo(px, py)
            else ctx.lineTo(px, py)
          }
          ctx.stroke()
        }
      }
    }

    // 当前时间标记线
    ctx.strokeStyle = '#40ff5e'
    ctx.lineWidth = 1
    ctx.beginPath()
    ctx.moveTo(W - 1, 0)
    ctx.lineTo(W - 1, H)
    ctx.stroke()

    // 更新歌词
    this.updateLyric(elapsed)

    // 到时停止
    if (elapsed >= this.data.totalSec * 1000) {
      this.stopRecording()
    }
  },

  getRefMidiAt(timeMs) {
    const song = this.songData
    if (!song || !song.refNotes) return 0
    for (let i = song.refNotes.length - 1; i >= 0; i--) {
      const n = song.refNotes[i]
      if (n.timeMs <= timeMs && n.timeMs + (n.durMs || 500) >= timeMs) return n.midi
    }
    return 0
  },

  updateLyric(elapsed) {
    const song = this.songData
    if (!song || !song.lyrics) return
    let currentIdx = -1
    for (let i = 0; i < song.lyrics.length; i++) {
      if (song.lyrics[i].timeMs <= elapsed) currentIdx = i
      else break
    }
    if (currentIdx >= 0) {
      const cur = song.lyrics[currentIdx]
      const next = currentIdx + 1 < song.lyrics.length ? song.lyrics[currentIdx + 1].text : ''
      if (cur.text !== this.data.currentLyric) {
        this.setData({ currentLyric: cur.text, nextLyric: next })
      }
    }
  },

  stopRecording() {
    if (this.drawTimer) { clearInterval(this.drawTimer); this.drawTimer = null }
    if (this.countdownTimer) { clearInterval(this.countdownTimer); this.countdownTimer = null }
    if (this.audioPlayer) { try { this.audioPlayer.stop() } catch (e) {} }
    try {
      wx.setStorageSync('karaoke_last_recording', {
        songId: this.data.songId,
        userMidiTrack: this.userMidiTrack || [],
        validFrames: this.validFrames || 0,
        totalFrames: this.totalFrames || 0,
        refNotes: this.songData ? this.songData.refNotes : null
      })
    } catch (e) { console.error('save recording', e) }
    this.cleanup()
    this.setData({ phase: 'settling', hintText: '确认查看成绩' })
  },

  goToResult() {
    wx.navigateTo({ url: '/pages/result/result?songId=' + this.data.songId })
  },

  cleanup() {
    if (this.drawTimer) { clearInterval(this.drawTimer); this.drawTimer = null }
    if (this.countdownTimer) { clearInterval(this.countdownTimer); this.countdownTimer = null }
    if (this.audioPlayer) {
      try { this.audioPlayer.stop() } catch (e) {}
      try { this.audioPlayer.destroy() } catch (e) {}
      this.audioPlayer = null
    }
    if (this.mediaStream) {
      try { this.mediaStream.getTracks().forEach(t => t.stop()) } catch (e) {}
      this.mediaStream = null
    }
    if (this.audioContext) {
      try { this.audioContext.close() } catch (e) {}
      this.audioContext = null
    }
    this.analyser = null
    this.sourceNode = null
  }
}
</script>

<page>
  <view class="page-root">
    <view class="topbar">
      <text class="song-name">{{songName}} · {{artist}}</text>
      <text class="timer">{{elapsedSec}}s</text>
    </view>

    <view class="lyric-bar" ink:if="{{phase === 'recording' || phase === 'countdown'}}">
      <text class="lyric-current">{{currentLyric}}</text>
      <text class="lyric-next">{{nextLyric}}</text>
    </view>

    <view class="canvas-wrap" ink:if="{{phase === 'recording' || phase === 'countdown'}}">
      <canvas id="pitchCanvas" class="pitch-canvas" width="448" height="180"></canvas>
    </view>

    <view class="countdown-overlay" ink:if="{{phase === 'countdown'}}">
      <text class="countdown-num">{{countdownNum}}</text>
    </view>

    <view class="center-wrap" ink:if="{{phase === 'loading'}}">
      <text class="center-title">{{songName}}</text>
      <text class="center-sub">伴奏已就绪</text>
    </view>

    <view class="center-wrap" ink:if="{{phase === 'error'}}">
      <text class="center-title">{{errorMsg}}</text>
    </view>

    <view class="center-wrap" ink:if="{{phase === 'settling'}}">
      <text class="center-title">收歌完成</text>
      <text class="center-sub">确认查看成绩</text>
    </view>

    <view class="hintbar">
      <text class="hint-text">{{hintText}}</text>
    </view>
  </view>
</page>

<style>
:root {
  --green-100: #40ff5e;
  --green-72: rgba(64,255,94,0.72);
  --green-48: rgba(64,255,94,0.48);
  --green-24: rgba(64,255,94,0.24);
  --green-12: rgba(64,255,94,0.12);
}

.page-root {
  display: flex;
  flex-direction: column;
  width: 448px;
  height: 328px;
}

.topbar {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  height: 26px;
  flex-shrink: 0;
  padding: 0 8px;
}

.song-name {
  font-size: 12px;
  color: var(--green-72);
}

.timer {
  font-size: 11px;
  color: var(--green-48);
}

.lyric-bar {
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 28px;
  flex-shrink: 0;
}

.lyric-current {
  font-size: 14px;
  font-weight: bold;
  color: var(--green-100);
}

.lyric-next {
  font-size: 10px;
  color: var(--green-24);
}

.canvas-wrap {
  display: flex;
  flex-direction: row;
  flex: 1 1 auto;
  min-height: 0;
}

.pitch-canvas {
  width: 448px;
  height: 180px;
}

.countdown-overlay {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: absolute;
  top: 54px;
  left: 0;
  width: 448px;
  height: 180px;
}

.countdown-num {
  font-size: 64px;
  font-weight: bold;
  color: var(--green-100);
}

.center-wrap {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex: 1 1 auto;
  min-height: 0;
}

.center-title {
  font-size: 18px;
  font-weight: bold;
  color: var(--green-100);
}

.center-sub {
  font-size: 12px;
  color: var(--green-48);
  margin-top: 8px;
}

.hintbar {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  height: 18px;
  flex-shrink: 0;
}

.hint-text {
  font-size: 10px;
  color: var(--green-24);
}
</style>