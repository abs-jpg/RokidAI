<script def>
{
  "usingComponents": {}
}
</script>

<script setup>
import wx from 'wx'
import { songs } from '../../utils/songData.js'

export default {
  data: {
    songs: songs,
    // 选中项索引：0~n-1 为歌曲，n~n+3 为功能入口
    // 功能入口：[songs.length] = 排行榜, [+1] = 联机, [+2] = 我的
    selectedIdx: 0,
    songCount: songs.length,
    // 功能入口定义
    navItems: [
      { label: '排行榜', icon: '榜' },
      { label: '联机对战', icon: '联' },
      { label: '我的', icon: '我' }
    ]
  },

  onShow() {
    // 回到首页时重置选中到第一首歌
    this.setData({ selectedIdx: 0 })
  },

  // 总可选数 = 歌曲数 + 功能入口数
  getTotalCount() {
    return this.data.songCount + this.data.navItems.length
  },

  // 判断当前选中是否是歌曲
  isSongSelected() {
    return this.data.selectedIdx < this.data.songCount
  },

  // 获取当前选中的歌曲
  getSelectedSong() {
    const idx = this.data.selectedIdx
    if (idx < this.data.songCount) {
      return this.data.songs[idx]
    }
    return null
  },

  // 获取当前选中的功能入口索引
  getSelectedNavIdx() {
    const idx = this.data.selectedIdx - this.data.songCount
    if (idx >= 0 && idx < this.data.navItems.length) {
      return idx
    }
    return -1
  },

  onKeyDown(event) {
    const code = event.code
    const total = this.getTotalCount()

    if (code === 'ArrowDown') {
      const next = (this.data.selectedIdx + 1) % total
      this.setData({ selectedIdx: next })
    } else if (code === 'ArrowUp') {
      const prev = (this.data.selectedIdx - 1 + total) % total
      this.setData({ selectedIdx: prev })
    } else if (code === 'Enter') {
      this.activateSelected()
    }
  },

  // bindtap 点击歌曲
  onTapSong(e) {
    const idx = e.currentTarget.dataset.idx
    if (idx != null && idx < this.data.songCount) {
      this.setData({ selectedIdx: idx })
      this.enterRecord(idx)
    }
  },

  // bindtap 点击功能入口
  onTapNav(e) {
    const navIdx = e.currentTarget.dataset.idx
    if (navIdx != null) {
      const selIdx = this.data.songCount + navIdx
      this.setData({ selectedIdx: selIdx })
      this.activateNav(navIdx)
    }
  },

  activateSelected() {
    if (this.isSongSelected()) {
      this.enterRecord(this.data.selectedIdx)
    } else {
      const navIdx = this.getSelectedNavIdx()
      if (navIdx >= 0) {
        this.activateNav(navIdx)
      }
    }
  },

  enterRecord(songIdx) {
    const song = this.data.songs[songIdx]
    if (song) {
      wx.navigateTo({
        url: '/pages/record/record?songId=' + song.id
      })
    }
  },

  activateNav(navIdx) {
    const routes = [
      '/pages/leaderboard/leaderboard',
      '/pages/match/match',
      '/pages/profile/profile'
    ]
    const route = routes[navIdx]
    if (route) {
      wx.navigateTo({ url: route })
    }
  }
}
</script>

<page>
  <view class="page-root">
    <!-- topbar -->
    <view class="topbar">
      <text class="title">K 歌</text>
      <text class="subtitle">选歌开唱</text>
    </view>

    <!-- 歌曲列表 -->
    <view class="song-list">
      <view
        class="song-item"
        ink:for="{{songs}}"
        ink:key="id"
        bindtap="onTapSong"
        data-idx="{{index}}"
      >
        <view class="song-marker">
          <view class="song-dot" ink:if="{{selectedIdx === index}}"></view>
        </view>
        <view class="song-info">
          <text class="song-name">{{item.name}}</text>
          <text class="song-artist">{{item.artist}}</text>
        </view>
        <text class="song-diff">
          <text ink:if="{{item.difficulty === 1}}">★☆☆</text>
          <text ink:elif="{{item.difficulty === 2}}">★★☆</text>
          <text ink:else>★★★</text>
        </text>
      </view>
    </view>

    <!-- 功能入口 -->
    <view class="nav-row">
      <view
        class="nav-item"
        ink:for="{{navItems}}"
        ink:key="label"
        bindtap="onTapNav"
        data-idx="{{index}}"
      >
        <view class="nav-marker">
          <view class="nav-dot" ink:if="{{selectedIdx === songCount + index}}"></view>
        </view>
        <text class="nav-label">{{item.label}}</text>
      </view>
    </view>

    <!-- hintbar -->
    <view class="hintbar">
      <text class="hint-text">上下选歌 · 确认开唱</text>
    </view>
  </view>
</page>

<style>
:root {
  --green-100: #40ff5e;
  --green-72: rgba(64,255,94,0.72);
  --green-48: rgba(64,255,94,0.48);
  --green-24: rgba(64,255,94,0.24);
  --green-12: rgba(64,255,94,0.12);
  --green-06: rgba(64,255,94,0.06);
}

.page-root {
  display: flex;
  flex-direction: column;
  width: 448px;
  height: 328px;
  padding: 0;
}

.topbar {
  display: flex;
  flex-direction: row;
  align-items: center;
  height: 30px;
  padding: 0 12px;
  flex-shrink: 0;
}

.title {
  font-size: 16px;
  font-weight: bold;
  color: var(--green-100);
}

.subtitle {
  font-size: 12px;
  color: var(--green-48);
  margin-left: 8px;
}

.song-list {
  display: flex;
  flex-direction: column;
  flex: 1 1 auto;
  min-height: 0;
  padding: 4px 12px;
}

.song-item {
  display: flex;
  flex-direction: row;
  align-items: center;
  height: 38px;
  padding: 0 8px;
  margin-bottom: 4px;
}

.song-marker {
  width: 16px;
  height: 38px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.song-dot {
  width: 6px;
  height: 6px;
  background-color: var(--green-100);
}

.song-info {
  display: flex;
  flex-direction: column;
  flex: 1 1 auto;
  min-width: 0;
  margin-left: 8px;
}

.song-name {
  font-size: 14px;
  color: var(--green-72);
}

.song-artist {
  font-size: 11px;
  color: var(--green-48);
  margin-top: 1px;
}

.song-diff {
  font-size: 12px;
  color: var(--green-48);
  flex-shrink: 0;
}

.nav-row {
  display: flex;
  flex-direction: row;
  height: 40px;
  padding: 0 12px;
  flex-shrink: 0;
}

.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex: 1 1 0;
  height: 40px;
}

.nav-marker {
  width: 100%;
  height: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.nav-dot {
  width: 5px;
  height: 5px;
  background-color: var(--green-100);
}

.nav-label {
  font-size: 12px;
  color: var(--green-48);
  margin-top: 2px;
}

.hintbar {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  height: 18px;
  flex-shrink: 0;
  padding: 0 12px;
}

.hint-text {
  font-size: 10px;
  color: var(--green-24);
}
</style>
